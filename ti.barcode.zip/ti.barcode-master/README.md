Titanium Barcode Module [![Build Status](https://travis-ci.org/appcelerator-modules/ti.barcode.svg)](https://travis-ci.org/appcelerator-modules/ti.barcode)
=======

This is the Barcode Module for Titanium built on top of the ZXing library.

## Contributors

Interested in contributing? Read the [contributors/committer's](https://wiki.appcelerator.org/display/community/Home) guide.

## Legal

This module is Copyright (c) 2010-2016 by Appcelerator, Inc. All Rights Reserved. Usage of this module is subject to 
the Terms of Service agreement with Appcelerator, Inc.
