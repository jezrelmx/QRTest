/**
 * This is a generated file. Do not edit or your changes will be lost
 */
#import "TiBarcodeModuleAssets.h"

extern NSData * dataWithHexString (NSString * hexString);

@implementation TiBarcodeModuleAssets

- (NSData*) moduleAsset
{
	return nil;
}

@end
